🛰️ BlinkPro Master

Servidor en tiempo real y panel web de monitoreo para la aplicación BlinkPro (Android).
Permite recibir métricas del dispositivo, mostrar su estado en vivo (🟢 Online / 🔴 Offline), tiempo de sesión, modelo, SDK y más, todo visualizado desde un panel web moderno alojado en Render.com.
